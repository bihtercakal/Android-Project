package com.example.bihter.labwork5_part2;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by bihter on 30.10.2016.
 */
public class FragmentThree extends Fragment {

    //  //inflate view inside fragment3
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle save){
        return inflater.inflate(R.layout.fragment_three,container, false);
    }
}
