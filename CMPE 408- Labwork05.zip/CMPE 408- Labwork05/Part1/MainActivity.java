package com.example.bihter.labwork05;

        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.RadioButton;
        import android.widget.TabHost;
        import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //variables
    TabHost tabhost;
    Button buttonOne;
    Button buttonTwo;
    Button buttonThree;
    Button buttonFour;
    RadioButton radioButton1;
    RadioButton radioButton2;
    RadioButton radioButton3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize variables
        tabhost = (TabHost) findViewById(android.R.id.tabhost);
        tabhost.setup();

        buttonOne = (Button) findViewById(R.id.buttonOne);
        buttonTwo = (Button) findViewById(R.id.buttonTwo);
        buttonThree = (Button) findViewById(R.id.buttonThree);
        buttonFour = (Button) findViewById(R.id.buttonFour);
        radioButton1 = (RadioButton) findViewById(R.id.radioButton1);
        radioButton2 = (RadioButton) findViewById(R.id.radioButton2);
        radioButton3 = (RadioButton) findViewById(R.id.radioButton3);

        //for buttons to activate
        radioButton1.setChecked(true);
        buttonOne.setOnClickListener(this);
        buttonTwo.setOnClickListener(this);
        buttonThree.setOnClickListener(this);
        buttonFour.setOnClickListener(this);

        TabHost.TabSpec tabSpec;

        //to create clock tab on the screen
        tabSpec = tabhost.newTabSpec("Screen-01");
        tabSpec.setContent(R.id.tabOne);
        tabSpec.setIndicator("Clock", null);
        tabhost.addTab(tabSpec);

        //to create text tab on the screen
        tabSpec = tabhost.newTabSpec("Screen-02");
        tabSpec.setContent(R.id.tabTwo);
        tabSpec.setIndicator("Text", null);
        tabhost.addTab(tabSpec);

        //to create Image tab on the screen
        tabSpec = tabhost.newTabSpec("Screen-03");
        tabSpec.setContent(R.id.tabImage);
        tabSpec.setIndicator("Image", null);
        tabhost.addTab(tabSpec);

        //to create color tab on the screen
        tabSpec = tabhost.newTabSpec("Screen-04");
        tabSpec.setContent(R.id.tabColor);
        tabSpec.setIndicator("Color", null);
        tabhost.addTab(tabSpec);

        tabhost.setCurrentTab(0);

        //When change the tab, seem to tab ID
        tabhost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {

                String text = "My Tab ID " + tabId;
                Toast.makeText(getApplicationContext(), text, 1).show();
            }
        });
    }

    //when click buttons in Color Tab, this method provides to change backgrounds color
    public void onClick (View w) {
        if(w == buttonOne) {
            //if user clicked buttonOne and choose radioButton1, clock's background color will be red
            if(radioButton1.isChecked()) {
                tabhost.findViewById(R.id.tabOne).setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
                //if choose radioButton2, clock's background color will be green
            }if(radioButton2.isChecked()) {
                tabhost.findViewById(R.id.tabOne).setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
                //if choose radioButton3, clock's background color will be blue
            } if(radioButton3.isChecked()){
                tabhost.findViewById(R.id.tabOne).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
            }}
        //if user click buttonTwo, this method provides to change text's background color
        else if(w==buttonTwo){
            //text's background will be red
            if(radioButton1.isChecked()) {
                tabhost.findViewById(R.id.tabTwo).setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
                //text's background will be green
            }if(radioButton2.isChecked()) {
                tabhost.findViewById(R.id.tabTwo).setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
                //text's background will be blue
            } if(radioButton3.isChecked()){
                tabhost.findViewById(R.id.tabTwo).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
            }
        }
        //if user click buttonThree, this method provides to change Image's background color
        else if (w==buttonThree){
            //Image's background will red
            if(radioButton1.isChecked()) {
                tabhost.findViewById(R.id.tabImage).setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
                //Image's background will be green
            }if(radioButton2.isChecked()) {
                tabhost.findViewById(R.id.tabImage).setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
                //Image's background will be blue
            } if(radioButton3.isChecked()){
                tabhost.findViewById(R.id.tabImage).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
            }
        }
        //if usr click buttonFour, this method provides to change Color's background color
        else if(w==buttonFour){
            //Color's background will be red
            if(radioButton1.isChecked()) {
                tabhost.findViewById(R.id.tabColor).setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
                //Color's background will be green
            }if(radioButton2.isChecked()) {
                tabhost.findViewById(R.id.tabColor).setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
                //Color's background will be blue
            } if(radioButton3.isChecked()){
                tabhost.findViewById(R.id.tabColor).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
            }
        }
    }
}